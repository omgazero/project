var cursor = new THREE.Vector2();
$(function() {
          var socket = io();
		  //console.log(socket);
          socket.on('wii', function(wiiMote) {
			  //console.log(wiiMote);
			let ww = $('#container').innerWidth();
			let hh = $('#container').innerHeight();
              cursor.x = (-(wiiMote.IRx[0]-512)/ ww )*2;
              cursor.y = (-(wiiMote.IRy[0]-349)/ hh )*2;

            let vec = new THREE.Vector3(cursor.x, cursor.y, -2);
            /*vec.unproject(camera);
            let dir = vec.sub(camera.position).normalize();
            let dis = (Zplane - camera.position.z) / dir.z;
            let pos = camera.position.clone().add(dir.multiplyScalar(dis));*/
            frontSight.position.copy(vec);
			wiiUp = wiiMote.Up;
			wiiDown = wiiMote.Down;
			wiiLeft = wiiMote.Left;
			wiiRight = wiiMote.Right;
			wiiA = wiiMote.A;
			//player.update(wiiMote);
			//console.log(wii);
			
          });
});